#!/bin/sh

PATH=.:$PATH
JoSchKaStarter.exe DistProtoAgent 1agent

