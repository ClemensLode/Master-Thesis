#Configdatei in Arbeitsverzeichnis kopieren
copy DistProtoAgent.config.xml D:\temp\DistProtoAgent.config.xml

#aktuelle Agentenversion direkt ins Arbeitsverzeichnis downloaden
$wc = new-object System.Net.WebClient
$wc.DownloadFile("http://aifbceres.aifb.uni-karlsruhe.de/DistProtoAgentDL/DistProtoAgent.exe", "D:\temp\DistProtoAgent.exe")
$wc.DownloadFile("http://aifbceres.aifb.uni-karlsruhe.de/DistProtoAgentDL/DistProtoAgent.XmlSerializers.dll", "D:\temp\DistProtoAgent.XmlSerializers.dll")
$wc.DownloadFile("http://aifbceres.aifb.uni-karlsruhe.de/DistProtoAgentDL/ICSharpCode.SharpZipLib.dll", "D:\temp\ICSharpCode.SharpZipLib.dll")

#Agentenprozesse starten, hier: 4 gleichzeitig
$psi = new-object System.Diagnostics.ProcessStartInfo
$psi.WorkingDirectory = "D:\temp"
$psi.FileName = "D:\temp\DistProtoAgent.exe"
$psi.Arguments = "-m"
[diagnostics.process]::Start($psi)
[diagnostics.process]::Start($psi)
[diagnostics.process]::Start($psi)
[diagnostics.process]::Start($psi)
